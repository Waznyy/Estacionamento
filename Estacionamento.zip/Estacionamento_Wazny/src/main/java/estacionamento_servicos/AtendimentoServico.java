package estacionamento_servicos;

import estacionamento_classes.Marca;
import estacionamento_repositorio.Repositorio;
import java.util.ArrayList;
import java.util.List;

public class AtendimentoServico {
    Repositorio repositorio = new Repositorio();
    public List<String> listarMarcas(){
         List<Marca> marcas = repositorio.obterTodasMarcas();
         List<String> nomeMarcas = new ArrayList<String>();
         for(Marca marca:marcas){
             nomeMarcas.add(marca.getNome());
         }
         return nomeMarcas;
    }
    
}
