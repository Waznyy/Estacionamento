package estacionamento_classes;

import java.util.List;

public interface IRepositorio {
    public List<Marca> obterTodasMarcas();
    public List<Modelo> obterTodosModelos();
    public List<Veiculo> obterTodosVeiculos();
    public List<Atendimento> obterTodosAtendimento();
    
}
