package estacionamento_classes;

public class Modelo {
   private int id;
   private String nome;
   private Marca marca;
   
   public Modelo(String nome, Marca marca){
       this.nome = nome;
       this.marca = marca;
   }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Marca getMarca() {
        return marca;
    }

    public void setMarca(Marca marca) {
        this.marca = marca;
    }
   
}
