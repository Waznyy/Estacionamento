
package estacionamento_classes;


public class teste {
    public static void main(String[] args){
        System.out.println("teste");
        
        Atendimento at1 = new Atendimento();
        at1.setManobrista("Jefferson");
        at1.setNmrVaga(3);
        System.out.println(at1.getManobrista());
        System.out.println(at1.getNmrVaga());
        
        Marca m1 = new Marca("Wolkswagen");
        Modelo mod1 = new Modelo("Parati", m1);
                
        Veiculo v1 = new Veiculo("DDK4258",mod1,"Cinza");
        
        System.out.println(v1.getPlaca()+ v1.getCor()+ v1.getModelo().getNome()+ v1.getModelo().getMarca().getNome());
    }
}
