package estacionamento_classes;

import java.util.List;

public class Marca {
    private int id;
    private String nome;
    private List<Modelo> modelos;
    
    public Marca(String nome){
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public List<Modelo> getModelos() {
        return modelos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
