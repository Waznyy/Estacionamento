package estacionamento_classes;

public class Veiculo {
    private int id;
    private String placa;
    private Modelo modelo;
    private String cor;
    
    public Veiculo(String placa, Modelo modelo, String cor){
        this.placa = placa;
        this.modelo = modelo;
        this.cor = cor;
    }   

    public int getId() {
        return id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Modelo getModelo() {
        return modelo;
    }

    public void setModelo(Modelo modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    
}
