
package estacionamento_classes;

import java.util.Date;


public class Atendimento {
    private int id;
    private Date dataEntrada;
    private Date dataSaida;
    private String manobrista;
    private Veiculo veiculo;
    private int nmrVaga;
    private double valorTotal;  
    
    public Atendimento(){
    }
    
    public int getId(){
        return this.id;
    }
    
    public Date getDataEntrada(){
        return this.dataEntrada;
    }
    
    public void setDataEntrada(Date dataEntrada){
        this.dataEntrada = dataEntrada;
    }
    
    public Date getDataSaida(){
        return this.dataSaida;
    }
    
    public void setDataSaida(Date dataSaida){
        this.dataSaida = dataSaida;
    }

    public String getManobrista(){
        return this.manobrista;
    }
    
    public void setManobrista(String manobrista){
        this.manobrista = manobrista;
    }
    
    public String getVeiculo(){
        return this.veiculo;
    }
    
    public void setVeiculo(String veiculo){
        this.veiculo = veiculo;
    }
    
    public int getNmrVaga(){
        return this.nmrVaga;
    }
    
    public void setNmrVaga(int nmrVaga){
        this.nmrVaga = nmrVaga;
    }
    
    public double getValorTotal(){
        return this.valorTotal;
    }
    
    public void setValorTotal(double valorTotal){
        this.valorTotal = valorTotal;
    }
}
