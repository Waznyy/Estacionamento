package estacionamento_repositorio;

import estacionamento_classes.Atendimento;
import estacionamento_classes.IRepositorio;
import estacionamento_classes.Marca;
import estacionamento_classes.Modelo;
import estacionamento_classes.Veiculo;
import java.util.ArrayList;
import java.util.List;

public class Repositorio implements IRepositorio {

    public Repositorio(){
        
    }
    
    @Override
    public List<Marca> obterTodasMarcas() {
        List<Marca> marcas = new ArrayList<>();
        
        marcas.add(new Marca("Wolkswagen"));
        marcas.add(new Marca("Chevrolet"));
        marcas.add(new Marca("Fiat"));
        
        return marcas;
    }

    @Override
    public List<Modelo> obterTodosModelos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Veiculo> obterTodosVeiculos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Atendimento> obterTodosAtendimento() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
